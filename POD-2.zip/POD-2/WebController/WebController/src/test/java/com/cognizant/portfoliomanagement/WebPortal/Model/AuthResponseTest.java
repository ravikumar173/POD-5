package com.cognizant.portfoliomanagement.WebPortal.Model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AuthResponseTest {

	@Test
	void test() {
		AuthResponse auth=new AuthResponse();
	}

}
