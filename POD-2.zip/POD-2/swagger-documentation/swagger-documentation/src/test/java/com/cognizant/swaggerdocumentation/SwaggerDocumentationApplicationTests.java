package com.cognizant.swaggerdocumentation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerDocumentationApplicationTests {

	@Test
	void contextLoads() {
	}

}
