insert into share_details values ('AMZ','Amazon',2500.0);
insert into share_details values ('GGL','Google',2000.0);
insert into share_details values ('ABC','Alpabet',1300.0);
insert into share_details values ('FFB','FaceBook',1400.0);